#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long long opCount;

typedef struct graph {
	int V;
	int **matrix;
	int costTotal;
}*Graph;

Graph initGraph(int V);
Graph insertEdge(Graph g, int from, int to, int weight);
Graph readInput(Graph g, char* fname, int *start);
void printGraph(Graph g, char* fname);

typedef struct minHeapNode { 
    int v; 
    int d; 
}MinHeapNode; 

typedef struct minHeap { 
    int size; 
    int capacity;
    int* pos;  
    MinHeapNode* array; 
}*MinHeap; 

MinHeapNode newMinHeapNode(int v, int d);
MinHeap createHeap(Graph g, int root);
void swapMinHeapNode(MinHeapNode* a, MinHeapNode* b);
void heapifyUp(MinHeap minHeap, int idx);
void heapifyDown(MinHeap heap, int idx);
MinHeap getMin(MinHeap heap);
MinHeap insertHeap(MinHeap minHeap, int v);