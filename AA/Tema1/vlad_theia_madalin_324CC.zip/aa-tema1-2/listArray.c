#include "listArray.h"

List initList(int v, int d) {
	List list;

	list = (List) malloc(sizeof(struct list));
	list->v = v;
    list->d = d;
	list->next = NULL;
	opCount += 4;
	return list;
}

List add(List list, int v, int d) {
	List new, tmp;

	if (list == NULL) {
		opCount++;
		return initList(v, d);
	}
	new = initList(v, d);
	tmp = list;
	while (tmp->next != NULL) {
		opCount++;
		tmp = tmp->next;
	}
	tmp->next = new;
	opCount += 4;
	return list;
}

Graph initGraph(int V) {
	int i;
	Graph g = (Graph)malloc(sizeof(struct graph));
	g->costTotal = 0;
	g->V = V;
	g->adjLists = (List*)malloc(V * sizeof(List));
	opCount += 3 + V;
	for (i = 0; i < V; i++) {
		g->adjLists[i] = NULL;
		opCount += 3;
	}
	return g;
}

Graph insertEdge(Graph g, int u, int v, int d) {
	g->adjLists[u] = add(g->adjLists[u], v, d);
	g->adjLists[v] = add(g->adjLists[v], u, d);
	g->costTotal += d;
	opCount += 3;
	return g;
}

Graph readInput(Graph g, char* fname, int *start) {
    int V, E, from, to, weight;
    
    FILE* f;
    f = fopen(fname, "r");
    
    fscanf(f, "%d %d", &E, &V);
    g = initGraph(V);
	fscanf(f, "%d", start);

    while(fscanf(f, "%d %d %d", &from, &to, &weight) != EOF) {
        g = insertEdge(g, from, to, weight);
    }

    fclose(f);

	return g;
}

void printGraph(Graph g, char* fname) {
	int i;
	List adjList;

	if (g == NULL) {
		printf("Null graph\n");
		return;
	}
    FILE* f;
    f = fopen(fname, "w");

	fprintf(f, "%d\n", g->costTotal);
	for (i = 0; i < g->V; i++) {
		adjList = g->adjLists[i];
		while (adjList != NULL) {
			if (i < adjList->v) {
				fprintf(f, "%d %d %d\n", i, adjList->v, adjList->d);
			}
			adjList = adjList->next;
		}
	}
    fprintf(f, "%lld\n", opCount);	
}

ArrayElem createArray(Graph g, int root, int *size, int *pos) {
	int i;
	ArrayElem arr = (ArrayElem) malloc(g->V * sizeof(struct arrayElem));
	opCount += g->V;
    for (i = 0; i < g->V; i++) {
	opCount += 3;
        arr[i].d = 100000;
	}
    arr[root].d = 0;

	List tmp = g->adjLists[root];
	while (tmp != NULL) {
        if (tmp->d != 0) {
            arr[(*size)].v = tmp->v;
            arr[(*size)].d = tmp->d;
            pos[tmp->v] = (*size);
            (*size)++;
            if ((*size) > 1) {
                arr = resortArr(tmp->v, arr, pos);
				opCount++;
            }
			opCount += 5;
        }
		tmp = tmp->next;
		opCount += 2;
	}
	return arr;
}

ArrayElem resortArr(int v, ArrayElem arr, int *pos) {
	ArrayElem x = (ArrayElem) malloc(sizeof(struct arrayElem));
	int index = pos[v];
	while (index > 0) {
		if (arr[index].d < arr[index - 1].d) {
			*x = arr[index];
			arr[index] = arr[index - 1];
			arr[index - 1] = *x;
			pos[arr[index].v] = index;
			pos[arr[index - 1].v] = index - 1;	
			opCount += 5;	
		}
		index--;
		opCount += 2;
	}
	opCount += 3;
	return arr;
}

ArrayElem getMin(ArrayElem arr, int size, int *pos) {
	int i;
	ArrayElem x = (ArrayElem) malloc(sizeof(struct arrayElem));
	opCount++;
	for (i = 0; i < size - 1; i++) {
		*x = arr[i];
		arr[i] = arr[i+1];
		arr[i+1] = *x;
		pos[arr[i].v] = i;	
		opCount += 6;
	}

	return arr;
}

ArrayElem insertArr(int v, ArrayElem arr, int *pos, int *size) {
    int ok = 1, i;
    for (i = 0; i < (*size); i++) {
		opCount += 3;
        if (arr[i].v == v) {
			opCount++;
            ok = 0;
		}
	}
    if (ok == 1) {
        arr[(*size)].v = v;
        arr[(*size)].d = arr[pos[v]].d;
        pos[v] = (*size);
        (*size)++;
		opCount += 4;
    }
    if ((*size) >= 1) {
		opCount++;
    	arr = resortArr(v, arr, pos);
    }
	opCount += 2;

	return arr;
}   