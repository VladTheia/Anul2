#include "matrixArray.h"

ArrayElem resortArr(int v, ArrayElem arr, int *pos) {
	ArrayElem x = (ArrayElem) malloc(sizeof(struct arrayElem));
	int index = pos[v];
	while (index > 0) {
		if (arr[index].d < arr[index - 1].d) {
			*x = arr[index];
			arr[index] = arr[index - 1];
			arr[index - 1] = *x;
			pos[arr[index].v] = index;
			pos[arr[index - 1].v] = index - 1;
			opCount += 5;		
		}
		index--;
		opCount += 2;
	}
	opCount += 3;
	return arr;
}

ArrayElem createArray(Graph g, int root, int *size, int *pos) {
	int i;
	ArrayElem arr = (ArrayElem) malloc(g->V * sizeof(struct arrayElem));
    opCount += g->V;

	for (i = 0; i < g->V; i++) {
        arr[i].d = 100000;
		opCount += 3;
	}
    arr[root].d = 0;
	opCount++;

	for (i = 0; i < g->V; i++)  {
        if (g->matrix[root][i] != 0) {
            arr[(*size)].v = i;
            arr[(*size)].d = g->matrix[root][i];
            pos[i] = (*size);
            (*size)++;
            if ((*size) > 1) {
                arr = resortArr(i, arr, pos);
				opCount++;
			}
			opCount += 5;
        }
		opCount += 3;
	}

	return arr;
}

ArrayElem getMin(ArrayElem arr, int size, int *pos) {
	int i;
	ArrayElem x = (ArrayElem) malloc(sizeof(struct arrayElem));
	
	for (i = 0; i < size - 1; i++) {
			*x = arr[i];
			arr[i] = arr[i+1];
			arr[i+1] = *x;
			pos[arr[i].v] = i;	
		}

	return arr;
}

ArrayElem insertArr(int v, ArrayElem arr, int *pos, int *size) {
    int ok = 1, i;
    for (i = 0; i < (*size); i++) {
        if (arr[i].v == v) {
            ok = 0;
			opCount++;
		}
		opCount += 3;
	}
    if (ok == 1) {
        arr[(*size)].v = v;
        arr[(*size)].d = arr[pos[v]].d;
        pos[v] = (*size);
        (*size)++;
		opCount += 4;	
    }
    if ((*size) >= 1) {
		opCount++;
    	arr = resortArr(v, arr, pos);
    }
	opCount += 2;

	return arr;
}   

Graph initGraph(int V) {
	Graph g;
	int i;

	g = (Graph) malloc(sizeof(struct graph));
	g->costTotal = 0;
	g->V = V;
	g->matrix = (int**) calloc(V, sizeof(int*));
	opCount += 3 + V;
	for (i = 0; i < V; i++) {
        g->matrix[i] = (int*) calloc(V, sizeof(int));
		opCount += 2 + V;
	}
	return g;
}   

Graph insertEdge(Graph g, int from, int to, int weight) {
	if (g == NULL) {
		opCount++;
		return g;
	}
	if (from >= g->V || to >= g->V) {
		opCount += 2;
		return g;
	}
	g->matrix[from][to] = weight;
	g->matrix[to][from] = weight;
	g->costTotal += weight;
	opCount += 6;
	return g;
}

Graph readInput(Graph g, char* fname, int *start) {
    int V, E, from, to, weight;
    
    FILE* f;
    f = fopen(fname, "r");
    
    fscanf(f, "%d %d", &E, &V);
    g = initGraph(V);
	fscanf(f, "%d", start);

    while(fscanf(f, "%d %d %d", &from, &to, &weight) != EOF) {
        g = insertEdge(g, from, to, weight);
    }

    fclose(f);

	return g;
}

void printGraph(Graph g, char* fname) {
	int i, j;

	if (g == NULL) {
		printf("Null graph\n");
		return;
	}
    FILE* f;
    f = fopen(fname, "w");

	fprintf(f, "%d\n", g->costTotal);
	for (i = 0; i < g->V; i++) 
		for (j = i; j < g->V; j++)
			if (g->matrix[i][j] != 0)
				fprintf(f, "%d %d %d\n", i, j, g->matrix[i][j]);
	fprintf(f, "%lld\n", opCount);	
}