#include "listHeap.h"

List initList(int v, int d) {
	List list;

	list = (List) malloc(sizeof(struct list));
	list->v = v;
    list->d = d;
	list->next = NULL;
    opCount += 4;

	return list;
}

List add(List list, int v, int d) {
	List new, tmp;

	if (list == NULL) {
        opCount++;
    	return initList(v, d);
    }
	new = initList(v, d);
	tmp = list;
	while (tmp->next != NULL){
		tmp = tmp->next;
        opCount++;
    }
	tmp->next = new;
    opCount += 4;

	return list;
}

Graph initGraph(int V) {
	int i;
	Graph g = (Graph)malloc(sizeof(struct graph));
	g->costTotal = 0;
	g->V = V;
	g->adjLists = (List*)malloc(V * sizeof(List));
    opCount += V + 3;
	for (i = 0; i < V; i++) {
		g->adjLists[i] = NULL;
        opCount += 3;
	}
	return g;
}

Graph insertEdge(Graph g, int u, int v, int d) {
	g->adjLists[u] = add(g->adjLists[u], v, d);
	g->adjLists[v] = add(g->adjLists[v], u, d);
	g->costTotal += d;
    opCount += 3;
	return g;
}

Graph readInput(Graph g, char* fname, int *start) {
    int V, E, from, to, weight;
    
    FILE* f;
    f = fopen(fname, "r");
    
    fscanf(f, "%d %d", &E, &V);
    g = initGraph(V);
	fscanf(f, "%d", start);

    while(fscanf(f, "%d %d %d", &from, &to, &weight) != EOF) {
        g = insertEdge(g, from, to, weight);
    }

    fclose(f);

	return g;
}

void printGraph(Graph g, char* fname) {
	int i;
	List adjList;

	if (g == NULL) {
		printf("Null graph\n");
		return;
	}
    FILE* f;
    f = fopen(fname, "w");

	fprintf(f, "%d\n", g->costTotal);
	for (i = 0; i < g->V; i++) {
		adjList = g->adjLists[i];
		while (adjList != NULL) {
			if (i < adjList->v) {
				fprintf(f, "%d %d %d\n", i, adjList->v, adjList->d);
			}
			adjList = adjList->next;
		}
	}
    fprintf(f, "%lld\n", opCount);	
}

MinHeapNode newMinHeapNode(int v, int d) { 
    MinHeapNode minHeapNode;
    minHeapNode.v = v; 
    minHeapNode.d = d; 
    opCount += 2;
    return minHeapNode; 
} 

MinHeap createHeap(Graph g, int root) {
    int capacity = g->V, i;
    MinHeap minHeap = (MinHeap)malloc(sizeof(struct minHeap)); 
    minHeap->pos = (int*)malloc(capacity * sizeof(int)); 
    minHeap->array = malloc(capacity * sizeof(struct minHeapNode)); 
    minHeap->capacity = capacity; 
    minHeap->size = 0;
    opCount += 3 + 2*capacity;

    for (i = 0; i < g->V; i++) {
        minHeap->array[i].d = 100000;
        minHeap->pos[i] = i;
        opCount += 4;
    }
    minHeap->array[root].d = 0;

    List tmp = g->adjLists[root];
	while (tmp != NULL) {
        if (tmp->d != 0) {
            minHeap->array[minHeap->size].v = tmp->v;
            minHeap->array[minHeap->size].d = tmp->d;
            minHeap->pos[tmp->v] = minHeap->size;
            minHeap->size++;
            if (minHeap->size > 1) {
                heapifyUp(minHeap, minHeap->size - 1);                
            }
            opCount += 5;
        }
		tmp = tmp->next;
        opCount += 2;
    }
    opCount += 3;

    return minHeap; 
}

void swapMinHeapNode(MinHeapNode* a, MinHeapNode* b) { 
    MinHeapNode t = *a; 
    *a = *b; 
    *b = t; 
    opCount += 3;
} 

void heapifyUp(MinHeap minHeap, int idx) { 
    int parentIdx = (idx - 1) / 2;

    if (minHeap->array[parentIdx].d > minHeap->array[idx].d) {
        minHeap->pos[minHeap->array[parentIdx].v] = idx;
        minHeap->pos[minHeap->array[idx].v] = parentIdx;
        opCount += 2;
        swapMinHeapNode(&minHeap->array[parentIdx], &minHeap->array[idx]);
        heapifyUp(minHeap, idx);
    }
    opCount +=2;
}

void heapifyDown(MinHeap heap, int idx) {
    int smallest = idx;
    int left = idx * 2 + 1;
    int right = idx *2 + 2;

    if (left < heap->size && heap->array[right].d < heap->array[idx].d) {
        smallest = left;
        opCount++;
    }

    if (right < heap->size && heap->array[right].d < heap->array[smallest].d) { 
        smallest = right;
        opCount++;
    }

    if (smallest != idx) {
        heap->pos[heap->array[smallest].v] = idx; 
        heap->pos[heap->array[idx].v] = smallest;
        opCount += 2;
        swapMinHeapNode(&heap->array[smallest], &heap->array[idx]);
        heapifyDown(heap, smallest); 
    }

    opCount += 8;
}

MinHeap getMin(MinHeap heap) {
    if (heap->size == 0) {
        opCount++;
        return NULL;
    }
    
    MinHeapNode last = heap->array[heap->size - 1];
    swapMinHeapNode(&last, &heap->array[0]);
    heap->pos[heap->array[0].v] = 0;
    heap->pos[last.v] = heap->size - 1;
    --heap->size;
    opCount += 5;
    heapifyDown(heap, 0);

    return heap;
}

MinHeap insertHeap(MinHeap minHeap, int v) {
    minHeap->array[minHeap->size].v = v;
    minHeap->array[minHeap->size].d = minHeap->array[minHeap->pos[v]].d;
    minHeap->pos[v] = minHeap->size;
    (minHeap->size)++;
    if (minHeap->size > 1) {
        heapifyUp(minHeap, minHeap->size - 1);
    }
    opCount += 5;

    return minHeap;
}