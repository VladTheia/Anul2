#include <stdio.h>
#include "matrixArray.h"

Graph prim1(Graph g, int root) {
	int V = g->V, u, v, size = 0;
    Graph AMA = initGraph(V);
    AMA = insertEdge(AMA, 0, 0, 0);
    opCount += 4;
    int p[V], pos[V];
    for (u = 0; u < V; u++) {
        pos[u] = u;
        p[u] = 0;
        opCount += 4;
    }
    ArrayElem arr = createArray(g, root, &size, pos);

     while(size > 0) {
        u = arr[0].v;
        AMA = insertEdge(AMA, u, p[u], arr[pos[u]].d);
        arr = getMin(arr, size, pos);
        size--;  
        opCount += 4;
        for (v = 0; v < V; v++) {
            if (AMA->matrix[u][v] == 0) {    
                if (g->matrix[u][v] != 0 
                    && g->matrix[u][v] < arr[pos[v]].d) {              
                        p[v] = u;
                        arr[pos[v]].d = g->matrix[u][v];
                        arr = insertArr(v, arr, pos, &size);
                        opCount += 3;
                   }
                opCount += 2;
            }
            opCount += 3;
        }
    }
    opCount += 2;

	return AMA;
}

int main(int argc, char *argv[]) {
    Graph g, AMA;
    int start;

    g = readInput(g, argv[1], &start);
    AMA = prim1(g, start);
	printGraph(AMA, argv[2]);
	
	return 0;
}