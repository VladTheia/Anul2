#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long long opCount;

//Implementarea algoritmului cu vector sortat la inserare
typedef struct arrayElem {
	int v;
	int d;
}*ArrayElem;

//Implementarea grafului cu matrice de adiacenta
typedef struct graph {
	int V;
	int **matrix;
	int costTotal;
}*Graph;


ArrayElem createArray(Graph g, int root, int *size, int *pos);
ArrayElem resortArr(int v, ArrayElem arr, int *pos);
ArrayElem getMin(ArrayElem arr, int size, int *pos);
ArrayElem insertArr(int v, ArrayElem arr, int *pos, int *size);

Graph initGraph(int V);
Graph insertEdge(Graph g, int from, int to, int weight);
Graph readInput(Graph g, char* fname, int *start);
void printGraph(Graph g, char* fname);