#include <stdio.h>
#include "listArray.h"

Graph prim2(Graph g, int root) {
	int V = g->V, u, v, size = 0, ok;
    Graph AMA = initGraph(V);
    AMA = insertEdge(AMA, 0, 0, 0);
    List tmp, tmpAMA;
    opCount += 4;
    int p[V], pos[V];
    for (u = 0; u < V; u++) {
        pos[u] = u;
        p[u] = 0;
        opCount += 4;
    }
    ArrayElem arr = createArray(g, root, &size, pos);

    while(size > 0) {
        u = arr[0].v;
        AMA = insertEdge(AMA, u, p[u], arr[pos[u]].d);
        arr = getMin(arr, size, pos);
        size--;
        opCount += 4;
        for (v = 0; v < V; v++) {
            ok = 0;
            tmpAMA = AMA->adjLists[u];
            while (tmpAMA != NULL) {
                if (tmpAMA->v != v) {
                    ok = 1;
                    opCount++;
                } else {
                    ok = 0;
                    opCount++;
                    break;
                } 
                tmpAMA = tmpAMA->next;
                opCount += 2;
            }
            if (ok) {
                tmp = g->adjLists[u];       
                while (tmp != NULL) {  
                    if (tmp->v == v && tmp->d < arr[pos[v]].d) {              
                        p[v] = u;
                        arr[pos[v]].d = tmp->d;
                        arr = insertArr(v, arr, pos, &size);
                        opCount += 3;
                    }
                    tmp = tmp->next;
                    opCount += 2;
                }
                opCount++;
            }
            opCount++;
        }
    }
    opCount++;

	return AMA;
}

int main(int argc, char *argv[]) {
    Graph g, AMA;
    int start;

    g = readInput(g, argv[1], &start);
    AMA = prim2(g, start);
	printGraph(AMA, argv[2]);
	
	return 0;
}