#include <stdio.h>
#include <stdlib.h>	

long long opCount;

typedef struct arrayElem {
	int v;
	int d;
}*ArrayElem;

typedef struct list {
	int v;
    int d;
	struct list *next;
}*List;

typedef struct graph {
	int V;
	List *adjLists;
	int costTotal;
}*Graph;

ArrayElem createArray(Graph g, int root, int *size, int *pos);
ArrayElem resortArr(int v, ArrayElem arr, int *pos);
ArrayElem getMin(ArrayElem arr, int size, int *pos);
ArrayElem insertArr(int v, ArrayElem arr, int *pos, int *size);

List initList(int v, int d);
List add(List list, int v, int d);
List freeList(List list);

Graph initGraph(int V);
Graph insertEdge(Graph g, int u, int v, int d);
Graph readInput(Graph g, char* fname, int *start);
void printGraph(Graph g, char* fname);