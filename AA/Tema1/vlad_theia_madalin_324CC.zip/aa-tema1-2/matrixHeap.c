#include "matrixHeap.h"

Graph initGraph(int V) {
	Graph g;
	int i;

	g = (Graph) malloc(sizeof(struct graph));
	g->costTotal = 0;
	g->V = V;
	g->matrix = (int**) calloc(V, sizeof(int*));
    opCount += 3 + V;
	for (i = 0; i < V; i++) {
        g->matrix[i] = (int*) calloc(V, sizeof(int));
        opCount += 2 + V;
    }
	return g;
}   

Graph insertEdge(Graph g, int from, int to, int weight) {
	if (g == NULL) {
		opCount++;
		return g;
	}
	if (from >= g->V || to >= g->V) {
		opCount += 2;
		return g;
	}
	g->matrix[from][to] = weight;
	g->matrix[to][from] = weight;
	g->costTotal += weight;
	opCount += 6;
	return g;
}

Graph readInput(Graph g, char* fname, int *start) {
    int V, E, from, to, weight;
    
    FILE* f;
    f = fopen(fname, "r");
    
    fscanf(f, "%d %d", &E, &V);
    g = initGraph(V);
	fscanf(f, "%d", start);

    while(fscanf(f, "%d %d %d", &from, &to, &weight) != EOF) {
        g = insertEdge(g, from, to, weight);
    }

    fclose(f);

	return g;
}

void printGraph(Graph g, char* fname) {
	int i, j;

	if (g == NULL) {
		printf("Null graph\n");
		return;
	}
    FILE* f;
    f = fopen(fname, "w");

	fprintf(f, "%d\n", g->costTotal);
	for (i = 0; i < g->V; i++) 
		for (j = i; j < g->V; j++)
			if (g->matrix[i][j] != 0)
				fprintf(f, "%d %d %d\n", i, j, g->matrix[i][j]);
	fprintf(f, "%lld\n", opCount);	
}

MinHeapNode newMinHeapNode(int v, int d) { 
    MinHeapNode minHeapNode;
    minHeapNode.v = v; 
    minHeapNode.d = d;
    opCount += 2;
    return minHeapNode; 
} 

MinHeap createHeap(Graph g, int root) {
    int capacity = g->V, i;
    MinHeap minHeap = (MinHeap)malloc(sizeof(struct minHeap)); 
    minHeap->pos = (int*)malloc(capacity * sizeof(int)); 
    minHeap->array = malloc(capacity * sizeof(struct minHeapNode)); 
    minHeap->capacity = capacity; 
    minHeap->size = 0;
    opCount += 4 + 2 * capacity;
    for (i = 0; i < g->V; i++) {
        minHeap->array[i].d = 100000;
        minHeap->pos[i] = i;
        opCount += 4;
    }
    minHeap->array[root].d = 0;
    opCount++;
    for (i = 0; i < g->V; i++) {
        if (g->matrix[root][i] != 0) {
                minHeap->array[minHeap->size].v = i;
                minHeap->array[minHeap->size].d = g->matrix[root][i];
                minHeap->pos[i] = minHeap->size;
                (minHeap->size)++;
                if (minHeap->size > 1) {
                    heapifyUp(minHeap, minHeap->size - 1);
                }
                opCount += 5;
        }
        opCount += 3;
    } 

    return minHeap; 
}

void swapMinHeapNode(MinHeapNode* a, MinHeapNode* b) { 
    MinHeapNode t = *a; 
    *a = *b; 
    *b = t; 
    opCount += 3;
} 

void heapifyUp(MinHeap minHeap, int idx) { 
    int parentIdx = (idx - 1) / 2;

    if (minHeap->array[parentIdx].d > minHeap->array[idx].d) {
        minHeap->pos[minHeap->array[parentIdx].v] = idx;
        minHeap->pos[minHeap->array[idx].v] = parentIdx;
        swapMinHeapNode(&minHeap->array[parentIdx], &minHeap->array[idx]);
        heapifyUp(minHeap, idx);
        opCount += 2;
    }
    opCount += 2;
}

void heapifyDown(MinHeap heap, int idx) {
    int smallest = idx;
    int left = idx * 2 + 1;
    int right = idx *2 + 2;

    if (left < heap->size && heap->array[right].d < heap->array[idx].d) {
        smallest = left;
        opCount++;
    }

    if (right < heap->size && heap->array[right].d < heap->array[smallest].d) {
        smallest = right;
        opCount++;
    } 

    if (smallest != idx) {
        heap->pos[heap->array[smallest].v] = idx; 
        heap->pos[heap->array[idx].v] = smallest;
        swapMinHeapNode(&heap->array[smallest], &heap->array[idx]);
        heapifyDown(heap, smallest);
        opCount += 2; 
    }
    opCount += 8;
}

MinHeap getMin(MinHeap heap) {
    if (heap->size == 0) {
        opCount++;
        return NULL;
    }
    
    MinHeapNode last = heap->array[heap->size - 1];
    swapMinHeapNode(&last, &heap->array[0]);
    heap->pos[heap->array[0].v] = 0;
    heap->pos[last.v] = heap->size - 1;
    --heap->size;
    heapifyDown(heap, 0);
    opCount += 6;
    return heap;
}

MinHeap insertHeap(MinHeap minHeap, int v) {
    minHeap->array[minHeap->size].v = v;
    minHeap->array[minHeap->size].d = minHeap->array[minHeap->pos[v]].d;
    minHeap->pos[v] = minHeap->size;
    (minHeap->size)++;
    if (minHeap->size > 1) {
        heapifyUp(minHeap, minHeap->size - 1);
    }
    opCount += 5;

    return minHeap;
}