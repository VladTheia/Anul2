#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long long opCount;

typedef struct minHeapNode { 
    int v; 
    int d; 
}MinHeapNode; 

typedef struct minHeap { 
    int size; 
    int capacity;
    int* pos;  
    MinHeapNode* array; 
}*MinHeap; 

typedef struct list {
	int v;
    int d;
	struct list *next;
}*List;

typedef struct graph {
	int V;
	List *adjLists;
	int costTotal;
}*Graph;

MinHeapNode newMinHeapNode(int v, int d);
MinHeap createHeap(Graph g, int root);
void swapMinHeapNode(MinHeapNode* a, MinHeapNode* b);
void heapifyUp(MinHeap minHeap, int idx);
void heapifyDown(MinHeap heap, int idx);
MinHeap getMin(MinHeap heap);
MinHeap insertHeap(MinHeap minHeap, int v);

List initList(int v, int d);
List add(List list, int v, int d);
List freeList(List list);

Graph initGraph(int V);
Graph insertEdge(Graph g, int u, int v, int d);
Graph readInput(Graph g, char* fname, int *start);
void printGraph(Graph g, char* fname);