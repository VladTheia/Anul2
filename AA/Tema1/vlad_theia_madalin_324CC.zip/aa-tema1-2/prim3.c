#include <stdio.h>
#include "matrixHeap.h"

Graph prim3(Graph g, int root) {
	int V = g->V, i, v;
    Graph AMA = initGraph(V);
    AMA = insertEdge(AMA, 0, 0, 0);

    int p[V];
    for (i = 0; i < V; i++)
        p[i] = 0;

    MinHeap heap = createHeap(g, root);
    while(heap->size > 0) {
        MinHeapNode u = heap->array[0];
        if (AMA->matrix[u.v][p[u.v]] == 0)
            AMA = insertEdge(AMA, u.v, p[u.v], u.d);
        heap = getMin(heap);
        for (v = 0; v < V; v++)
            if (AMA->matrix[u.v][v] == 0)    
                if (g->matrix[u.v][v] != 0 &&
                    g->matrix[u.v][v] < heap->array[heap->pos[v]].d) {              
                        p[v] = u.v;
                        heap->array[heap->pos[v]].d = g->matrix[u.v][v];
                        heap = insertHeap(heap, v);
                   }
     }

	return AMA;
}

int main(int argc, char *argv[]) {
    Graph g, AMA;
    int start;
    g = readInput(g, argv[1], &start);
    AMA = prim3(g, start);
	printGraph(AMA, argv[2]);

	return 0;
}