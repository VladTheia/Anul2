#include <stdio.h>
#include "listHeap.h"

Graph prim4(Graph g, int root) {
	int V = g->V, i, v, ok;
    opCount++;
    Graph AMA = initGraph(V);
    AMA = insertEdge(AMA, 0, 0, 0);
    List tmpAMA, tmp;

    int p[V];
    for (i = 0; i < V; i++) {
        p[i] = 0;
        opCount += 3;
    }

    MinHeap heap = createHeap(g, root);
    while(heap->size > 0) {
        MinHeapNode u = heap->array[0];
        tmpAMA = AMA->adjLists[u.v];
        ok = 1;
        opCount += 3;
        while (tmpAMA != NULL) {
            if (tmpAMA->v == p[u.v]) {
                ok = 0;
                break;
            }
            else {
                ok = 1;
            }
            tmpAMA = tmpAMA->next;
            opCount += 3;
        }
        opCount++;
        if (ok) {
            AMA = insertEdge(AMA, u.v, p[u.v], u.d);
        }
        opCount++;
        heap = getMin(heap);

        for (v = 0; v < V; v++) {
            ok = 0;
            tmpAMA = AMA->adjLists[u.v];
            while (tmpAMA != NULL) {
                if (tmpAMA->v != v) {
                    ok = 1;

                } else {
                    ok = 0;
                    break;
                }
                tmpAMA = tmpAMA->next;
                opCount += 3;
            }
            opCount++;
            if (ok) {
                tmp = g->adjLists[u.v];       
                while (tmp != NULL) {  
                    if (tmp->v == v && tmp->d < heap->array[heap->pos[v]].d) {              
                        p[v] = u.v;
                        heap->array[heap->pos[v]].d = tmp->d;
                        heap = insertHeap(heap, v);
                        opCount += 3;
                    }
                    tmp = tmp->next;
                    opCount += 3;
                }
                opCount++;
            }
            opCount++;
        }
    }
    opCount++;

	return AMA;
}

int main(int argc, char *argv[]) {
    Graph g, AMA;
    int start;
    g = readInput(g, argv[1], &start);
    AMA = prim4(g, start);
	printGraph(AMA, argv[2]);
	
	return 0;
}