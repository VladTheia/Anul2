public interface Observer {
    void update(Notification notification);
}
