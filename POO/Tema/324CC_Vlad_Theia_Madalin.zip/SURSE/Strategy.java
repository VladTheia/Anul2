public interface Strategy {
    Item execute(WishList wishList);
}
